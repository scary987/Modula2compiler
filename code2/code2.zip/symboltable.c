#include <stdlib.h>
#include <string.h>
#include "scanner.h"
#include "symboltable.h"

symboltable_element* root = NULL;

/* ADD YOUR CODE HERE */
