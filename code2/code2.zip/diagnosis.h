/* THIS FILE IS PART OF THE ASSIGNMENT AND MUST NOT BE CHANGED! */

#ifndef __DIAGNOSIS_H
#define __DIAGNOSIS_H

/* display an error message and abort the program */
void yyerror(char const* msg);

#endif
