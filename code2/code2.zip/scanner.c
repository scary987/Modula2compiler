#include <ctype.h>
#include "buffer.h"
#include "scanner.h"
#include "diagnosis.h"

int yylineno = 1;

/* ADD YOUR CODE HERE */
